import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
df = pd.read_csv('dataset.csv')
print(df.head())
#read csv file and display sample data for ensuring proper reading